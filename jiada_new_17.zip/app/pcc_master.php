<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class pcc_master extends Model
{
    public $timestamps = false;
	public  $table = "pcc_master";
}
