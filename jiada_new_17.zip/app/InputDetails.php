<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InputDetails extends Model
{
    protected $primaryKey = 'id';
	public  $table = "input_details";
}
