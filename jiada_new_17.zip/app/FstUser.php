<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FstUser extends Model
{
	public $timestamps = false;
	public  $table = "fst";
}
