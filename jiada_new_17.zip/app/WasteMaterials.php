<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class WasteMaterials extends Model
{
    protected $primaryKey = 'id';
	public  $table = "waste_materials";
}
