<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class entity_master extends Model
{
    public $timestamps = false;
	public  $table = "entity_master";
}
