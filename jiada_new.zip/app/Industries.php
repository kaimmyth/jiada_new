<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Industries extends Model
{
    protected $primaryKey = 'id';
	public  $table = "industries";
}
