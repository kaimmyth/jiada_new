<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AllLocationblock extends Model
{
	public $timestamps = false;
	public  $table = "location_block";
}
