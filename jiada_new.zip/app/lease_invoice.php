<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class lease_invoice extends Model
{
	public $timestamps = false;
	public  $table = "lease_invoice";
}
