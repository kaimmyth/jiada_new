<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IndustriesMaster extends Model
{
    //
}
