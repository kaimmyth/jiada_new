<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AllLocationzone extends Model
{
	public $timestamps = false;
	public  $table = "location_zone";
}
