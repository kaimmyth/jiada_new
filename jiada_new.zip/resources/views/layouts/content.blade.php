@include('layouts.header')
@include($data['content'])
@include('layouts.footer')